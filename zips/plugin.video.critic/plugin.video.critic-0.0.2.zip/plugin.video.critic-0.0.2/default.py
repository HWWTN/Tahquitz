# -*- coding: utf-8 -*-
#------------------------------------------------------------
# kodi tutorials from the group
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: lesismore
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.critic'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "ChrisStuckmann"
YOUTUBE_CHANNEL_ID_2 = "JeremyJahns"
YOUTUBE_CHANNEL_ID_3 = "achannelthatsawesome"
YOUTUBE_CHANNEL_ID_4 = "CinemaSins"
YOUTUBE_CHANNEL_ID_5 = "theFLICKpick"
YOUTUBE_CHANNEL_ID_6 = "ScreenRant"
YOUTUBE_CHANNEL_ID_7 = "screenjunkies"
YOUTUBE_CHANNEL_ID_8 = "UCOZcxtwy_YYe7KKky8DCLGQ"
YOUTUBE_CHANNEL_ID_9 = "mrsundaymovies"
YOUTUBE_CHANNEL_ID_10 = "schmoesknow"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Chris Stuckmann",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Jeremy Jahns",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Nostalgia Critics",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cinema Sins",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="The Flick Pick",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )	
  
    plugintools.add_item( 
        #action="", 
        title="Screen Rant",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Screen Junkies",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Couch Tomato",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Mr. Sunday Movies",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )		
   
    plugintools.add_item( 
        #action="", 
        title="Smchoes Knows",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://weclipart.com/gimg/8BE5B9B515EA8C42/eTMdERBrc.jpeg",
        folder=True )
		
run()
