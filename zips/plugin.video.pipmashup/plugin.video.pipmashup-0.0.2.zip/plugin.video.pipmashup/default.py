# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Pippy's Pick's 
# Author: Gracie and Pippy


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"
YOUTUBE_CHANNEL_ID_1 = "PL991qh8jWvSeq9ngAHz-UDynkxv-IivcJ"
YOUTUBE_CHANNEL_ID_2 = "PL991qh8jWvSf4kR8TSK7PrPIWTweLckOQ"
YOUTUBE_CHANNEL_ID_3 = "PL991qh8jWvSdvXZGfdtopFXLZ6Vwmh9op"
YOUTUBE_CHANNEL_ID_4 = "PL991qh8jWvSf9A9E-i0sxcn7kp47IF5QG"
YOUTUBE_CHANNEL_ID_5 = "PL991qh8jWvSfwyNbE-Yes2nEOa_mjhQbV"
YOUTUBE_CHANNEL_ID_6 = "PL991qh8jWvSfB3ZEElVSkYCA_1bWUlXc2"
YOUTUBE_CHANNEL_ID_7 = "PL991qh8jWvSdEg7omYWW3s3qZRTAot5Oi"
YOUTUBE_CHANNEL_ID_8 = "PL991qh8jWvSfmBfmD-XmhHiOTYYQRljBl"
YOUTUBE_CHANNEL_ID_9 = "PL991qh8jWvSeUqevXF4QH-qHUFnKJ39uQ"
YOUTUBE_CHANNEL_ID_10= "PL991qh8jWvSf602_shPxtWdP7_ADuuQQw"
YOUTUBE_CHANNEL_ID_11= "PL991qh8jWvSeeJQJVD_fYFsUc0v2-N28s"
YOUTUBE_CHANNEL_ID_12= "PL991qh8jWvSfDiE9jyvvX3W-WJyFPCAhC"
YOUTUBE_CHANNEL_ID_13= "PL991qh8jWvSd5iD8lBnqxJ_MStwnUsFLE"
YOUTUBE_CHANNEL_ID_14= "PL991qh8jWvScldUP7Nf1wAYOCX2lYDrNV"


@route(mode='main_menu')
def Main_Menu():

	Add_Dir( 
        name="Try Not To Laugh", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://archive.org/download/trynottolaugh/trynottolaugh.jpg")

	Add_Dir( 
        name="The Floor is Lava", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://ia801502.us.archive.org/14/items/graciesmiles242_gmail_Lava/lava.jpg")
		
	Add_Dir( 
		name="Roblox Videos", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://ia601504.us.archive.org/3/items/roblox_20171213/roblox.jpg")
	
	Add_Dir( 
        name="Roblox Music Videos", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://archive.org/download/robloxmusic/robloxmusic.jpg")
	
	Add_Dir( 
		name="Try Not To Sing", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://archive.org/download/trynotsing/trynotsing.jpg")
	
	Add_Dir( 
        name="Silly and Adorable Animals", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://ia601507.us.archive.org/16/items/animals_201712/animals.jpg")	
	
	Add_Dir( 
        name="My Favorite Music", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://ia801503.us.archive.org/29/items/mymusic_20171212_2353/mymusic.jpg")
	
	Add_Dir( 
        name="Pippy's Picks", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://archive.org/download/pippyspicks/pippyspicks.jpg")	
		
	Add_Dir( 
        name="Toddlers", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://archive.org/download/toddler/toddler.jpg")
	
	Add_Dir( 
		name="Muppets", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
		icon="https://ia601506.us.archive.org/21/items/muppets_201712/muppets.jpg")
		
	Add_Dir( 
		name="Disney", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
		icon="https://ia601503.us.archive.org/28/items/disney_201712/disney.jpg")
		
	Add_Dir( 
		name="Silly Songs", url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
		icon="https://ia601501.us.archive.org/12/items/silly_201712/silly.jpg")	
	
	Add_Dir( 
        name="Educational", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
        icon="https://ia601504.us.archive.org/27/items/school_201712/school.jpg")
	
	Add_Dir( 
        name="Ellen", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
        icon="https://archive.org/download/pippyspicks/pippyspicks.jpg")
		
		
		
		


@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)



if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))